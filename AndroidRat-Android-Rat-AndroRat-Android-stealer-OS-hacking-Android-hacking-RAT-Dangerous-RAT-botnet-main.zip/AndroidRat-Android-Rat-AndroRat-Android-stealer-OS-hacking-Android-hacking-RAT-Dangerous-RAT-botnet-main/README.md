# AndroidRat-Android-Rat-AndroRat-Android-stealer-OS-hacking-Android-hacking-RAT-Dangerous-RAT-botnet
AndroRAT | Remote Administrator Tool for Android OS Hacking
 
TEST AVAILABLE , TIMEWASTER PLS STAY AWAY DIRECT BLOCK 

It Works from Android 7 to Android 15 
 
**All the available functionalities are  
**  
   
- Remote control 
- Pattern+pin+passcode stealer
- Auto Unlock screen with recorded pattern
- Hidden control(make screen blank when using victims phones)
- Sms contact stealer
- Hide notification + make volume silent
- File manager
- Camera access
- Micro phone access
- Keylogger
- Install app remotely
- GUID+dropper
  
And many more and can be made additional features on request can’t list all here


**Check Screensots & Videos  :-
**




**Features :-
**

![three](https://files.catbox.moe/hqtesi.jpg) 


**Files Access :-
**


![four](https://files.catbox.moe/ez7xsq.jpg) 


**GUI Controler:-
**

![five](https://files.catbox.moe/59m7rn.jpg) 


**DEMO VIDEOS :-
**
 
##Live Screen Access

for demo videos contact me

Telegram: (https://t.me/banknshop)






Contact Me:
Telegram: (https://t.me/banknshop)

I ALSO SELL BANK LOGS IN BLACKBET 